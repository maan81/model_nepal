<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Ethnicity of the models
 */

$config['ethnicity'] = array(
								'brahmin',		
								'gurung',
								'limbu',		
								'magar',
								'newar',		
								'rai',
								'rana',			
								'sherpa',
								'tamang',		
								'thakali',
								'thakuri',		
								'tibetan Origin'
							);


/* End of file ethnicity.php */
/* Location: ./application/config/ethnicity.php */