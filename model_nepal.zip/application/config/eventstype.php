<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Types of events
 */

$config['eventstype'] = array(
							'dance'		=>	'Dance Party',		
							'fashion'	=>	'Fashion Show',
							'pagent'	=>	'Pagent',		
						);


/* End of file eventstype.php */
/* Location: ./application/config/eventstype.php */