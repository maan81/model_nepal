<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Different types of News-Gossips-Artitles
 */

$config['news_type'] = array(
								'health'	=>	'Health & Exercise',		
							);


/* End of file news_type.php */
/* Location: ./application/config/news_type.php */