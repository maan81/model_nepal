<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-05 08:48:38 --> Query error: Unknown column 'upcomming' in 'where clause'
ERROR - 2013-05-05 08:53:01 --> 404 Page Not Found --> public
ERROR - 2013-05-05 08:53:01 --> 404 Page Not Found --> public
ERROR - 2013-05-05 08:53:42 --> 404 Page Not Found --> public
ERROR - 2013-05-05 08:53:43 --> 404 Page Not Found --> public
ERROR - 2013-05-05 09:03:13 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-05 09:23:14 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-05 10:46:36 --> 404 Page Not Found --> featured/up
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1283
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1285
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1292
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1283
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1285
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1292
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1283
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1285
ERROR - 2013-05-05 11:12:04 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1292
ERROR - 2013-05-05 11:21:40 --> 404 Page Not Found --> subjects/up
ERROR - 2013-05-05 11:25:45 --> Severity: Notice  --> Undefined property: Subjects::$subject_model C:\wamp\www\model_nepal\application\controllers\admin\subjects.php 256
