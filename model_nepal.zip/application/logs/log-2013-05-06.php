<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-06 05:40:41 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-06 05:44:47 --> 404 Page Not Found --> public
ERROR - 2013-05-06 05:45:14 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 837
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 839
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 846
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 837
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 839
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 846
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 837
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 839
ERROR - 2013-05-06 05:45:34 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 846
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 837
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 839
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 846
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 837
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 839
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 846
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 837
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 839
ERROR - 2013-05-06 05:45:45 --> Severity: Notice  --> Undefined property: stdClass::$position C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 846
ERROR - 2013-05-06 08:19:12 --> 404 Page Not Found --> public
ERROR - 2013-05-06 08:19:12 --> 404 Page Not Found --> public
ERROR - 2013-05-06 08:26:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\model_nepal\application\controllers\admin\ads.php 97
ERROR - 2013-05-06 08:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\model_nepal\application\controllers\admin\ads.php 100
ERROR - 2013-05-06 08:26:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\model_nepal\application\controllers\admin\ads.php 103
ERROR - 2013-05-06 08:27:39 --> 404 Page Not Found --> events/up
ERROR - 2013-05-06 09:05:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\model_nepal\application\controllers\admin\ads.php 100
ERROR - 2013-05-06 09:07:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\model_nepal\application\controllers\admin\ads.php 100
ERROR - 2013-05-06 10:19:57 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-06 10:19:57 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-06 11:53:45 --> Query error: Unknown column '0' in 'where clause'
ERROR - 2013-05-06 11:56:35 --> Query error: Unknown column '0' in 'where clause'
ERROR - 2013-05-06 11:56:53 --> Query error: Unknown column '0' in 'where clause'
ERROR - 2013-05-06 11:58:18 --> Query error: Unknown column '0' in 'where clause'
ERROR - 2013-05-06 11:58:36 --> Query error: Unknown column '0' in 'where clause'
ERROR - 2013-05-06 11:59:00 --> Query error: Unknown column 'upcomming' in 'where clause'
ERROR - 2013-05-06 12:02:43 --> 404 Page Not Found --> public
ERROR - 2013-05-06 12:02:43 --> 404 Page Not Found --> public
