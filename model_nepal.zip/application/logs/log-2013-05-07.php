<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-07 05:28:22 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-07 05:28:49 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-07 05:29:11 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-07 05:29:28 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-07 05:29:52 --> 404 Page Not Found --> public
ERROR - 2013-05-07 05:37:49 --> 404 Page Not Found --> contests
ERROR - 2013-05-07 05:38:19 --> 404 Page Not Found --> admin/contests
ERROR - 2013-05-07 06:18:51 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-07 06:23:37 --> 404 Page Not Found --> contests
ERROR - 2013-05-07 08:32:50 --> 404 Page Not Found --> public
ERROR - 2013-05-07 08:32:50 --> 404 Page Not Found --> public
ERROR - 2013-05-07 08:33:13 --> 404 Page Not Found --> public
ERROR - 2013-05-07 08:33:21 --> 404 Page Not Found --> public
ERROR - 2013-05-07 08:36:25 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\model_nepal\application\models\flinks_model.php 113
ERROR - 2013-05-07 08:36:26 --> 404 Page Not Found --> public
ERROR - 2013-05-07 08:36:27 --> 404 Page Not Found --> public
ERROR - 2013-05-07 08:41:10 --> Severity: Notice  --> Undefined property: stdClass::$dimensions C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1118
ERROR - 2013-05-07 08:42:52 --> Severity: Notice  --> Undefined property: stdClass::$dimensions C:\wamp\www\model_nepal\application\libraries\adminrender_library.php 1118
ERROR - 2013-05-07 08:45:28 --> Severity: Notice  --> Undefined variable: table C:\wamp\www\model_nepal\application\models\flinks_model.php 179
ERROR - 2013-05-07 08:46:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\models\flinks_model.php 167
ERROR - 2013-05-07 08:51:06 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\model_nepal\application\models\flinks_model.php 113
ERROR - 2013-05-07 08:54:23 --> The upload path does not appear to be valid.
ERROR - 2013-05-07 08:55:01 --> The upload path does not appear to be valid.
ERROR - 2013-05-07 08:55:53 --> Severity: Warning  --> Creating default object from empty value C:\wamp\www\model_nepal\application\models\flinks_model.php 113
ERROR - 2013-05-07 09:12:28 --> Severity: Notice  --> Undefined variable: data C:\wamp\www\model_nepal\application\controllers\admin\flinks.php 131
ERROR - 2013-05-07 09:15:43 --> Severity: Warning  --> unlink(public/flinks/0): No such file or directory C:\wamp\www\model_nepal\application\models\flinks_model.php 169
ERROR - 2013-05-07 09:21:00 --> Severity: Warning  --> unlink(public/flinks/0): No such file or directory C:\wamp\www\model_nepal\application\models\flinks_model.php 163
ERROR - 2013-05-07 09:21:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\model_nepal\application\controllers\admin\flinks.php 202
ERROR - 2013-05-07 09:21:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\model_nepal\application\controllers\admin\flinks.php 248
ERROR - 2013-05-07 09:21:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\model_nepal\application\controllers\admin\flinks.php 248
ERROR - 2013-05-07 09:22:35 --> 404 Page Not Found --> public
ERROR - 2013-05-07 09:24:08 --> Severity: Warning  --> unlink(public/flinks/0): No such file or directory C:\wamp\www\model_nepal\application\models\flinks_model.php 163
ERROR - 2013-05-07 09:27:34 --> The uploaded file exceeds the maximum allowed size in your PHP configuration file.
ERROR - 2013-05-07 09:36:01 --> Severity: Notice  --> Undefined variable: tmp3 C:\wamp\www\model_nepal\application\controllers\main.php 79
ERROR - 2013-05-07 09:36:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\libraries\render_library.php 346
ERROR - 2013-05-07 10:27:55 --> Severity: Notice  --> Undefined index: flinks
	                	 C:\wamp\www\model_nepal\application\libraries\render_library.php 326
ERROR - 2013-05-07 10:29:58 --> Severity: Notice  --> Undefined index: flinks
	                	 C:\wamp\www\model_nepal\application\libraries\render_library.php 327
ERROR - 2013-05-07 10:30:28 --> Severity: Notice  --> Undefined index: flinks
	                	 C:\wamp\www\model_nepal\application\libraries\render_library.php 327
ERROR - 2013-05-07 10:31:01 --> Severity: Notice  --> Undefined index: flinks
	                	 C:\wamp\www\model_nepal\application\libraries\render_library.php 327
ERROR - 2013-05-07 10:34:47 --> Severity: Notice  --> Undefined property: stdClass::$links C:\wamp\www\model_nepal\application\libraries\render_library.php 340
ERROR - 2013-05-07 10:48:13 --> 404 Page Not Found --> public
ERROR - 2013-05-07 10:48:15 --> 404 Page Not Found --> public
ERROR - 2013-05-07 10:59:19 --> Severity: Notice  --> Undefined variable: op C:\wamp\www\model_nepal\application\libraries\render_library.php 341
