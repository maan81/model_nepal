<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-08 06:21:57 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 06:22:30 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 06:46:01 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:46:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:46:09 --> Severity: Notice  --> Undefined property: stdClass::$tile C:\wamp\www\model_nepal\application\views\site\events_selected_hor.php 20
ERROR - 2013-05-08 06:46:09 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:46:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:50:19 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:50:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:50:53 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:50:53 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:52:10 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 06:52:34 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 06:59:10 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 06:59:12 --> Severity: Notice  --> Undefined property: stdClass::$tile C:\wamp\www\model_nepal\application\views\site\events_selected_hor.php 20
ERROR - 2013-05-08 07:03:05 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 07:03:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 07:04:03 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 07:04:03 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 07:14:07 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 07:14:07 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 07:19:06 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 07:19:13 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-08 07:19:13 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-08 07:20:32 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-08 07:20:32 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-08 07:20:35 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-08 07:20:35 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-08 07:23:35 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-08 07:23:35 --> Severity: Notice  --> Undefined index: name C:\wamp\www\model_nepal\application\views\site\subjects_selected.php 117
ERROR - 2013-05-08 07:31:13 --> Severity: Notice  --> Undefined variable: flinks C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 07:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\model_nepal\application\views\site\right_part.php 34
ERROR - 2013-05-08 07:44:24 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 07:44:26 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 07:44:40 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 07:47:15 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\wamp\www\model_nepal\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-05-08 07:58:36 --> 404 Page Not Found --> public
ERROR - 2013-05-08 07:58:36 --> 404 Page Not Found --> public
